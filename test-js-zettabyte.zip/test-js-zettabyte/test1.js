// Expected Result = 55
// Direction : Return sum of array
const input = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

function result(input) {
  let arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  let sum = arr.reduce(function (a, b) {
    return a + b;
  }, 0);

  console.log(sum);
}

console.log(result(input));