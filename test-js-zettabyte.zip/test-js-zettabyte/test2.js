// Expected result : [7, 3, 1, 2, 5, 6, 9, 10, 4, 8]
// Direction : Mutate arr1 to return combined array with arr2. The conditions are :
// 1. odd number at beginning 
// 2. even number at the end of array 
// 3. Original arr1 at the middle

const arr1 = [1, 2, 5, 6, 9, 10];
const arr2 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

function result(arr1, arr2) {
  var arr1 = [1, 2, 5, 6, 9, 10];
  var arr2 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  var genap = [];
  var ganjil = [];
  var i = 0;

	for(i; i <arr2.length; i++){
		if (arr2[i] % 2 == 0) {
			genap.push(arr2[i]);
		}else{
			ganjil.push(arr2[i]);
		}
	}
    console.log(ganjil, arr1, genap);		
}

console.log(result(arr1, arr2));