<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        return view('tes_html_css');
      #  return view('welcome_message');
    }
}
