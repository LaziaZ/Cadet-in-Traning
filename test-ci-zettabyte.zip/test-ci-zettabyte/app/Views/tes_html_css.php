<!DOCTYPE html>
<html>
<head>
<style>
.flex-container {
  display: flex;
  flex-wrap: nowrap;
  background-color: #f1f1f1;
}

.flex-container > div {
  background-color: white;
  height: 300px;
  width: 210px;
  margin: 10px;
  text-align: center;
  line-height: 75px;
  font-size: 30px;
}

.flex-container .thumb {
  padding-bottom: 10%;
  background-size: cover;
  background-position: center center;
}

</style>
</head>
<body>

<div class="flex-container">
  <div class="thumb"><img height="100%" width="100%" src="<?=base_url('');?>/DCIM/3x4.jpg" alt="3x4"/><button onclick='jacascript:alert("Foto diri ukuran 3x4")' href='#'>Foto 3x4</button></div>
  <div class="thumb"><img height="100%" width="100%" src="<?=base_url('');?>/DCIM/4x6.jpg" alt="4x6"/><button onclick='jacascript:alert("Foto diri ukuran 4x6")' href='#'>Foto 4x6</button></div>
  <div class="thumb"><img height="100%" width="100%" src="<?=base_url('');?>/DCIM/Sertifikat Junior Web Programmer.jpg" alt="sertifikat"><button onclick='jacascript:alert("Softcopy Sertifikat Junior Web Programmer")' href='#'>Sertifikat Junior Web Programmer</button></div>
  <div class="thumb"><img height="100%" width="100%" src="<?=base_url('');?>/DCIM/Sertifikat Operator Komputer.jpg" alt="sertifikat"><button onclick='jacascript:alert("Softcopy Sertifikat Operator Komputer")' href='#'>Sertifikat Operator Komputer</button></div>  
</div>
</body>
</html>